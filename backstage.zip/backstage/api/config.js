/**
 * 腾讯云配置
*/

const tencentConfig = {
    /** 云API密钥 SecretId*/
    SecretId : "AKIDWrvjGWVEgJkwta1C9qHSO4VfZCZfW7SW",
    SecretKey : "pOmvoSqztXw5yb092f3B3g3C6j6D3bsu"
}

/**
 * mongoDB数据库
 */
const mongoConfig = {
    url: 'mongodb://localhost/english',
    option: {
        useNewUrlParser: true,
        useUnifiedTopology: true
    }
}
/**
 * sms短信验证码
 */
const smsConfig = {
    //短信应用ID
    SmsSdkAppid: "1400699816"
}

const miniprogramConfig = {
AppID : "wx186970802b102bbc",
AppSecret : "d5fe13da592041a47823562193dbf046"
}

module.exports = {
tencentConfig,
mongoConfig,
smsConfig,
miniprogramConfig
}






